import {
  Component, Input, Output, EventEmitter,
  signal, ViewChild, ElementRef, AfterViewInit
} from '@angular/core';
import { SwipeCarouselItem } from '../../core/interfaces/interfaces.models';
import { CommonModule } from '@angular/common';
import { PhotoUploadComponent } from "../photo-upload/photo-upload.component";

@Component({
  selector: 'app-swipe-carousel',
  standalone: true,
  imports: [CommonModule, PhotoUploadComponent],
  templateUrl: './swipe-carousel.component.html',
  styleUrls: ['./swipe-carousel.component.scss']
})
export class SwipeCarouselComponent implements AfterViewInit {
  @Input({ required: true }) items: SwipeCarouselItem[] = [];
  @Input() selectedIndex = 0;
  @Input() missionId!: string;


  @Output() itemSelected = new EventEmitter<SwipeCarouselItem>();
  @Output() selectAdd = new EventEmitter<void>();

  currentIndex = signal(0);

  itemWidth = 0;
  private container?: HTMLElement;
  private startX = 0;
  private deltaX = 0;
  private dragging = false;

  ngAfterViewInit() {
    this.container = document.querySelector('.carousel-track') as HTMLElement;

    const wrapper = this.container?.parentElement as HTMLElement;
    this.itemWidth = wrapper?.offsetWidth || 300;

    if (this.container) {
  this.container?.addEventListener('pointermove', this.onPointerMove.bind(this), { passive: false });

      this.container.addEventListener('pointerdown', this.onPointerDown.bind(this));
      this.container.addEventListener('pointerup', this.onPointerUp.bind(this));
    }

    setTimeout(() => this.scrollTo(this.selectedIndex), 0);
  }

  scrollTo(index: number) {
    if (!this.container) return;
    this.currentIndex.set(index);
  }

  prev() {
    this.scrollTo(Math.max(0, this.currentIndex() - 1));
  }

  next() {
    this.scrollTo(Math.min(this.items.length - 1, this.currentIndex() + 1));
  }

  onItemClick(index: number) {
    const item = this.items[index];
    if (item.isAddButton) {
      this.selectAdd.emit();
    } else if (index === this.currentIndex()) {
      this.itemSelected.emit(item);
    } else {
      this.scrollTo(index);
    }
  }

  onPointerDown(event: PointerEvent) {
    this.startX = event.clientX;
    this.deltaX = 0;
    this.dragging = true;
    this.container?.setPointerCapture(event.pointerId);
  }

onPointerMove(event: PointerEvent) {
  if (!this.dragging) return;

  this.deltaX = event.clientX - this.startX;

  // Si mouvement horizontal significatif, empêcher scroll vertical
  if (Math.abs(this.deltaX) > 10) {
    event.preventDefault();
  }
}

  onPointerUp(event: PointerEvent) {
    if (!this.dragging) return;
    this.dragging = false;

    const threshold = this.itemWidth / 3;

    if (this.deltaX > threshold) {
      this.prev();
    } else if (this.deltaX < -threshold) {
      this.next();
    }

    this.deltaX = 0;
    this.container?.releasePointerCapture(event.pointerId);
  }
}
