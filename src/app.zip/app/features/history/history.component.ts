import { Component } from '@angular/core';

@Component({
  selector: 'app-history.component',
  imports: [],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent {

}
