import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery.component',
  imports: [],
  templateUrl: './gallery.component.html',
  styleUrl: './gallery.component.scss'
})
export class GalleryComponent {

}
